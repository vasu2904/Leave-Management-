# Team 26 - Edspread Project - Leave Management System

# Installing Node Modules

npm install

# Starting Frontend

npm start
