import React from "react";
import Home from "./Components/Home";
import Header from "./Components/Header";
import Footer from "./Components/Footer";

function App() {
  //   const [backendData, setBackendData] = useState([{}]);
  //   useEffect(() => {
  //     fetch("/").then((response) => setBackendData(response));
  //   }, []);
  return (
    <>
      <Header />
      <Home />
      <Footer />
    </>
  );
}

export default App;
