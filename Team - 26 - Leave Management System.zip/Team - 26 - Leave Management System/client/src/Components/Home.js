import React from "react";

function home() {
  return (
    <div>
      <h1>Leave Management System</h1>
    </div>
  );
}

export default home;
