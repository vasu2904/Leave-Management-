import React from "react";

const Footer = () => {
  let footerStyle = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    color: "white",
    width: "100%",
    height: "50px",
    position: "absolute",
    bottom: "0px",
    backgroundColor: "rgb(30, 30, 30)",
  };
  return (
    <div style={footerStyle}>
      <p>Copy &copy; Vasu, Murali, and Kaushik.</p>
    </div>
  );
};

export default Footer;
