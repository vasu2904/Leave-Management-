# Leave Management System

## Technology Stack Used :

- Backednd : NodeJS,
- Database : Mongodb
- FrontEnd : JS, Html, css, React
- Framework : Express

## Installing Node Modules

npm install

# Running

node app.js

# or

nodemon app.js
